موقع الأستاذ بشير بن يحيى | EduTech
===================================

الموقع يحتوي على:
- index.html: الصفحة الرئيسية المتجاوبة مع الهاتف والكمبيوتر.
- assets/bechir-ben-yahia.jpg: الصورة الشخصية التي زودتني بها.

معاينة:
افتح index.html في متصفح بعد فك ضغط الملف.

النشر المجاني على Vercel:
1. أنشئ حساباً في https://vercel.com/
2. أنشئ مستودعاً جديداً في https://github.com/ وارفع إليه index.html ومجلد assets كاملاً.
3. في Vercel اختر Add New > Project ثم اربط مستودع GitHub.
4. اضغط Deploy. ستحصل على رابط عام من نوع *.vercel.app.

بيانات التواصل المضافة:
- البريد: Bechirbenyahia@gmail.com
- Facebook: https://www.facebook.com/share/1EwqXrYbkX/?mibextid=wwXIfr

ملاحظة:
هذه نسخة جاهزة للمعاينة والتخصيص، لكنها لم تُنشر على الإنترنت بعد.
الرابط العام لا يصبح فعالاً إلا بعد إتمام النشر في حساب الاستضافة.
